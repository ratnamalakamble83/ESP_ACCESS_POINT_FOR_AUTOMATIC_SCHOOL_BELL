#include "eeprom.h"

#include "nvs.h"
#include "nvs_flash.h"
#include "esp_log.h"
#include <string.h>

static const char *TAG = "EEPROM";

#define NVS_NAMESPACE "school_bell"
#define KEY_BELLS     "bells"
#define KEY_COUNT     "count"


/* =========================================================
 * INITIALIZE NVS
 * ========================================================= */

esp_err_t eeprom_init(void)
{
    esp_err_t ret;

    ret = nvs_flash_init();

    if (ret == ESP_ERR_NVS_NO_FREE_PAGES ||
        ret == ESP_ERR_NVS_NEW_VERSION_FOUND)
    {
        ESP_LOGW(
            TAG,
            "NVS needs erase"
        );

        ret = nvs_flash_erase();

        if (ret != ESP_OK)
        {
            return ret;
        }

        ret = nvs_flash_init();
    }

    if (ret == ESP_OK)
    {
        ESP_LOGI(
            TAG,
            "NVS initialized"
        );
    }

    return ret;
}


/* =========================================================
 * SAVE BELLS
 * ========================================================= */

esp_err_t eeprom_save_bells(
    const EEPROM_BellTime *bells,
    uint8_t total_bells)
{
    nvs_handle_t handle;

    esp_err_t ret;

    if (total_bells > EEPROM_MAX_BELLS)
    {
        total_bells = EEPROM_MAX_BELLS;
    }


    /* Open NVS */

    ret = nvs_open(
        NVS_NAMESPACE,
        NVS_READWRITE,
        &handle
    );

    if (ret != ESP_OK)
    {
        ESP_LOGE(
            TAG,
            "NVS open failed: %s",
            esp_err_to_name(ret)
        );

        return ret;
    }


    /* Store bell array */

    ret = nvs_set_blob(
        handle,
        KEY_BELLS,
        bells,
        sizeof(EEPROM_BellTime) * total_bells
    );

    if (ret != ESP_OK)
    {
        ESP_LOGE(
            TAG,
            "Failed to save bells"
        );

        nvs_close(handle);

        return ret;
    }


    /* Store number of bells */

    ret = nvs_set_u8(
        handle,
        KEY_COUNT,
        total_bells
    );

    if (ret != ESP_OK)
    {
        ESP_LOGE(
            TAG,
            "Failed to save bell count"
        );

        nvs_close(handle);

        return ret;
    }


    /* Commit */

    ret = nvs_commit(handle);

    if (ret != ESP_OK)
    {
        ESP_LOGE(
            TAG,
            "NVS commit failed"
        );
    }
    else
    {
        ESP_LOGI(
            TAG,
            "Saved %d bell(s) to NVS",
            total_bells
        );
    }


    nvs_close(handle);

    return ret;
}

esp_err_t eeprom_delete_bell(uint8_t index)
{
    EEPROM_BellTime bells[EEPROM_MAX_BELLS];
    uint8_t total_bells = 0;
    esp_err_t ret;

    /* Load existing bells */
    ret = eeprom_load_bells(bells, &total_bells);

    if (ret != ESP_OK)
    {
        return ret;
    }

    /* Check index */
    if (index >= total_bells)
    {
        ESP_LOGE(TAG, "Invalid bell index: %d", index);
        return ESP_ERR_INVALID_ARG;
    }

    /* Shift remaining bells */
    for (uint8_t i = index; i < total_bells - 1; i++)
    {
        bells[i] = bells[i + 1];
    }

    /* Reduce count */
    total_bells--;

    /* Save updated list to NVS */
    ret = eeprom_save_bells(bells, total_bells);

    if (ret == ESP_OK)
    {
        ESP_LOGI(TAG,
                 "Deleted bell at index %d. Remaining bells: %d",
                 index,
                 total_bells);
    }

    return ret;
}

/* =========================================================
 * LOAD BELLS
 * ========================================================= */

esp_err_t eeprom_load_bells(
    EEPROM_BellTime *bells,
    uint8_t *total_bells)
{
    nvs_handle_t handle;

    esp_err_t ret;

    size_t required_size;

    uint8_t count = 0;


    *total_bells = 0;


    /* Open NVS */

    ret = nvs_open(
        NVS_NAMESPACE,
        NVS_READONLY,
        &handle
    );

    if (ret == ESP_ERR_NVS_NOT_FOUND)
    {
        ESP_LOGI(
            TAG,
            "No saved bell schedule"
        );

        return ESP_OK;
    }

    if (ret != ESP_OK)
    {
        ESP_LOGE(
            TAG,
            "NVS open failed"
        );

        return ret;
    }


    /* Read count */

    ret = nvs_get_u8(
        handle,
        KEY_COUNT,
        &count
    );

    if (ret == ESP_ERR_NVS_NOT_FOUND)
    {
        nvs_close(handle);

        ESP_LOGI(
            TAG,
            "No saved bell count"
        );

        return ESP_OK;
    }

    if (ret != ESP_OK)
    {
        nvs_close(handle);

        return ret;
    }


    /* Check maximum */

    if (count > EEPROM_MAX_BELLS)
    {
        count = EEPROM_MAX_BELLS;
    }


    /* Get blob size */

    required_size =
        sizeof(EEPROM_BellTime) * count;


    if (count > 0)
    {
        ret = nvs_get_blob(
            handle,
            KEY_BELLS,
            bells,
            &required_size
        );

        if (ret != ESP_OK)
        {
            ESP_LOGE(
                TAG,
                "Failed to load bells: %s",
                esp_err_to_name(ret)
            );

            nvs_close(handle);

            return ret;
        }
    }


    *total_bells = count;


    nvs_close(handle);


    ESP_LOGI(
        TAG,
        "Loaded %d bell(s) from NVS",
        count
    );


    return ESP_OK;
}


/* =========================================================
 * CLEAR BELLS
 * ========================================================= */

esp_err_t eeprom_clear_bells(void)
{
    nvs_handle_t handle;

    esp_err_t ret;


    ret = nvs_open(
        NVS_NAMESPACE,
        NVS_READWRITE,
        &handle
    );

    if (ret != ESP_OK)
    {
        return ret;
    }


    nvs_erase_key(
        handle,
        KEY_BELLS
    );

    nvs_erase_key(
        handle,
        KEY_COUNT
    );


    ret = nvs_commit(handle);

    nvs_close(handle);


    ESP_LOGI(
        TAG,
        "All bell data cleared"
    );


    return ret;
}
