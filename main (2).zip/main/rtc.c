
#include "rtc.h"

#include "driver/i2c.h"
#include "esp_log.h"

/* =========================================================
 * DS1307 I2C SETTINGS
 * ========================================================= */

#define RTC_I2C_PORT       I2C_NUM_0
#define RTC_SDA_PIN        GPIO_NUM_8
#define RTC_SCL_PIN        GPIO_NUM_9
#define RTC_I2C_FREQ       100000
#define RTC_ADDRESS        0x68

static const char *TAG = "RTC";


/* =========================================================
 * BCD CONVERSION FUNCTIONS
 * ========================================================= */

/* Decimal to BCD */
static uint8_t dec_to_bcd(uint8_t value)
{
    return ((value / 10) << 4) | (value % 10);
}


/* BCD to Decimal */
static uint8_t bcd_to_dec(uint8_t value)
{
    return ((value >> 4) * 10) + (value & 0x0F);
}


/* =========================================================
 * RTC INITIALIZATION
 * ========================================================= */

esp_err_t rtc_initialize(void)
{
    i2c_config_t config =
    {
        .mode = I2C_MODE_MASTER,

        .sda_io_num = RTC_SDA_PIN,
        .scl_io_num = RTC_SCL_PIN,

        .sda_pullup_en = GPIO_PULLUP_ENABLE,
        .scl_pullup_en = GPIO_PULLUP_ENABLE,

        .master.clk_speed = RTC_I2C_FREQ
    };


    esp_err_t ret;


    /* Configure I2C parameters */
    ret = i2c_param_config(RTC_I2C_PORT, &config);

    if (ret != ESP_OK)
    {
        ESP_LOGE(TAG, "I2C parameter configuration failed");
        return ret;
    }


    /* Install I2C driver */
    ret = i2c_driver_install(
        RTC_I2C_PORT,
        I2C_MODE_MASTER,
        0,
        0,
        0
    );


    /* Driver may already be installed */
    if (ret == ESP_ERR_INVALID_STATE)
    {
        ESP_LOGW(TAG, "I2C driver already installed");
        return ESP_OK;
    }


    if (ret != ESP_OK)
    {
        ESP_LOGE(TAG, "I2C driver installation failed: %s",
                 esp_err_to_name(ret));

        return ret;
    }


    ESP_LOGI(TAG, "RTC I2C Initialized");

    return ESP_OK;
}


/* =========================================================
 * SET DATE AND TIME
 * ========================================================= */

esp_err_t rtc_set_datetime(const rtc_time_t *time)
{
    /* Check pointer */
    if (time == NULL)
    {
        return ESP_ERR_INVALID_ARG;
    }


    /*
     * DS1307 register map:
     *
     * 0x00 = Seconds
     * 0x01 = Minutes
     * 0x02 = Hours
     * 0x03 = Day
     * 0x04 = Date
     * 0x05 = Month
     * 0x06 = Year
     */


    /*
     * data[0] = Starting register address
     *
     * data[1] = Seconds
     * data[2] = Minutes
     * data[3] = Hours
     * data[4] = Day
     * data[5] = Date
     * data[6] = Month
     * data[7] = Year
     */

    uint8_t data[8];


    /* Start writing from register 0x00 */
    data[0] = 0x00;


    /*
     * Seconds
     *
     * Bit 7 = CH (Clock Halt)
     * It must be 0 for the clock to run.
     */

    data[1] = dec_to_bcd(time->second) & 0x7F;


    /* Minutes */
    data[2] = dec_to_bcd(time->minute) & 0x7F;


    /*
     * Hours
     *
     * DS1307 is configured for 24-hour mode.
     * Bit 6 = 0
     */

    data[3] = dec_to_bcd(time->hour) & 0x3F;


    /*
     * Day of week
     *
     * 1 = Sunday
     * 2 = Monday
     * 3 = Tuesday
     * 4 = Wednesday
     * 5 = Thursday
     * 6 = Friday
     * 7 = Saturday
     */

    data[4] = dec_to_bcd(time->day) & 0x07;


    /* Date: 1 to 31 */
    data[5] = dec_to_bcd(time->date) & 0x3F;


    /* Month: 1 to 12 */
    data[6] = dec_to_bcd(time->month) & 0x1F;


    /*
     * Year
     *
     * DS1307 stores only two digits.
     *
     * Example:
     * 2026 -> 26
     */

    data[7] = dec_to_bcd(time->year);


    /* Write all 7 RTC registers */
    esp_err_t ret = i2c_master_write_to_device(
        RTC_I2C_PORT,
        RTC_ADDRESS,
        data,
        sizeof(data),
        pdMS_TO_TICKS(1000)
    );


    if (ret == ESP_OK)
    {
        ESP_LOGI(
            TAG,
            "RTC Set: %02d/%02d/20%02d %02d:%02d:%02d",
            time->date,
            time->month,
            time->year,
            time->hour,
            time->minute,
            time->second
        );
    }
    else
    {
        ESP_LOGE(
            TAG,
            "RTC write failed: %s",
            esp_err_to_name(ret)
        );
    }


    return ret;
}


/* =========================================================
 * GET DATE AND TIME
 * ========================================================= */

esp_err_t rtc_get_datetime(rtc_time_t *time)
{
    /* Check pointer */
    if (time == NULL)
    {
        return ESP_ERR_INVALID_ARG;
    }


    /*
     * Start reading from register 0x00
     */

    uint8_t reg = 0x00;

    uint8_t data[7];

    esp_err_t ret;


    /*
     * Write register address 0x00
     * Then read 7 bytes
     */

    ret = i2c_master_write_read_device(
        RTC_I2C_PORT,
        RTC_ADDRESS,
        &reg,
        1,
        data,
        7,
        pdMS_TO_TICKS(1000)
    );


    if (ret != ESP_OK)
    {
        ESP_LOGE(
            TAG,
            "RTC read failed: %s",
            esp_err_to_name(ret)
        );

        return ret;
    }


    /*
     * Convert BCD values to decimal values
     */

    /* Seconds */
    time->second = bcd_to_dec(data[0] & 0x7F);


    /* Minutes */
    time->minute = bcd_to_dec(data[1] & 0x7F);


    /* Hours */
    time->hour = bcd_to_dec(data[2] & 0x3F);


    /* Day of week */
    time->day = bcd_to_dec(data[3] & 0x07);


    /* Date */
    time->date = bcd_to_dec(data[4] & 0x3F);


    /* Month */
    time->month = bcd_to_dec(data[5] & 0x1F);


    /* Year */
    time->year = bcd_to_dec(data[6]);


    return ESP_OK;
}

