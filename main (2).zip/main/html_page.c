
#include "html_page.h"

const char html_page[] =

"<!DOCTYPE html>"
"<html>"

"<head>"

"<meta charset='UTF-8'>"

"<meta name='viewport' "
"content='width=device-width, initial-scale=1.0'>"

"<title>Automatic School Bell</title>"

/* =========================================================
 * CSS
 * ========================================================= */

"<style>"

"*{"
"box-sizing:border-box;"
"}"

"body{"
"margin:0;"
"font-family:Arial,Helvetica,sans-serif;"
"background:#f1f5f9;"
"color:#1e293b;"
"}"

".header{"
"background:#1769aa;"
"color:white;"
"padding:20px;"
"text-align:center;"
"box-shadow:0 2px 8px rgba(0,0,0,0.2);"
"}"

".header h1{"
"margin:0;"
"font-size:26px;"
"}"

".header p{"
"margin:6px 0 0;"
"font-size:14px;"
"opacity:0.9;"
"}"

".status{"
"display:inline-block;"
"margin-top:10px;"
"padding:6px 14px;"
"border-radius:20px;"
"background:#16a34a;"
"color:white;"
"font-size:13px;"
"font-weight:bold;"
"}"

".container{"
"max-width:850px;"
"margin:20px auto;"
"padding:0 15px;"
"}"

".card{"
"background:white;"
"border-radius:14px;"
"padding:20px;"
"margin-bottom:18px;"
"box-shadow:0 3px 12px rgba(0,0,0,0.08);"
"}"

".time-title{"
"text-align:center;"
"font-size:14px;"
"color:#64748b;"
"font-weight:bold;"
"}"

".clock{"
"text-align:center;"
"font-size:42px;"
"font-weight:bold;"
"color:#1769aa;"
"margin:8px 0;"
"}"

".date{"
"text-align:center;"
"font-size:15px;"
"color:#64748b;"
"}"

".section-title{"
"font-size:19px;"
"font-weight:bold;"
"margin-bottom:15px;"
"}"

".next-bell{"
"background:#e0f2fe;"
"border-left:5px solid #0284c7;"
"border-radius:10px;"
"padding:18px;"
"text-align:center;"
"}"

".next-time{"
"font-size:32px;"
"font-weight:bold;"
"color:#0369a1;"
"}"

".next-event{"
"font-size:18px;"
"font-weight:bold;"
"margin-top:5px;"
"}"

".next-info{"
"margin-top:8px;"
"font-size:14px;"
"color:#475569;"
"}"

"label{"
"display:block;"
"font-weight:bold;"
"margin-top:12px;"
"margin-bottom:6px;"
"}"

"input,select{"
"width:100%;"
"padding:13px;"
"border:1px solid #cbd5e1;"
"border-radius:8px;"
"font-size:16px;"
"outline:none;"
"background:white;"
"}"

"input:focus,select:focus{"
"border-color:#1769aa;"
"}"

".add-btn{"
"width:100%;"
"margin-top:18px;"
"padding:14px;"
"background:#1769aa;"
"color:white;"
"border:none;"
"border-radius:8px;"
"font-size:16px;"
"font-weight:bold;"
"cursor:pointer;"
"}"

".add-btn:hover{"
"background:#12558b;"
"}"

".message{"
"text-align:center;"
"margin-top:12px;"
"font-weight:bold;"
"min-height:20px;"
"}"

".table-container{"
"overflow-x:auto;"
"}"

"table{"
"width:100%;"
"border-collapse:collapse;"
"min-width:850px;"
"}"

"th{"
"background:#1769aa;"
"color:white;"
"padding:12px 8px;"
"text-align:left;"
"}"

"td{"
"padding:12px 8px;"
"border-bottom:1px solid #e2e8f0;"
"}"

"tr:hover{"
"background:#f8fafc;"
"}"

"td button{"
"background:#dc2626;"
"color:white;"
"border:none;"
"padding:7px 10px;"
"border-radius:6px;"
"cursor:pointer;"
"}"

".status-row{"
"display:flex;"
"justify-content:space-between;"
"padding:11px 0;"
"border-bottom:1px solid #e2e8f0;"
"}"

".status-row:last-child{"
"border-bottom:none;"
"}"

".ok{"
"color:#16a34a;"
"font-weight:bold;"
"}"

".footer{"
"text-align:center;"
"color:#64748b;"
"font-size:12px;"
"padding:15px;"
"}"

"@media(max-width:500px){"

".header h1{"
"font-size:22px;"
"}"

".clock{"
"font-size:34px;"
"}"

".card{"
"padding:16px;"
"}"

".next-time{"
"font-size:28px;"
"}"

"th,td{"
"font-size:14px;"
"}"

"}"

"</style>"

"</head>"

/* =========================================================
 * BODY
 * ========================================================= */

"<body>"

"<div class='header'>"

"<h1>AUTOMATIC SCHOOL BELL</h1>"

"<p>ESP32 Bell Controller</p>"

"<div class='status'>SYSTEM ONLINE</div>"

"</div>"

"<div class='container'>"

/* =========================================================
 * CURRENT TIME
 * ========================================================= */

"<div class='card'>"

"<div class='time-title'>CURRENT TIME</div>"

"<div class='clock' id='clock'>"
"00:00:00"
"</div>"

"<div class='date' id='date'>"
"Loading..."
"</div>"

"</div>"

/* =========================================================
 * NEXT BELL
 * ========================================================= */

"<div class='card'>"

"<div class='section-title'>"
"NEXT BELL"
"</div>"

"<div class='next-bell'>"

"<div class='next-time' id='nextTime'>"
"--:--"
"</div>"

"<div class='next-event' id='nextEvent'>"
"No bell scheduled"
"</div>"

"<div class='next-info' id='nextInfo'>"
"Waiting for schedule..."
"</div>"

"</div>"

"</div>"

/* =========================================================
 * RTC DATE & TIME
 * ========================================================= */

"<div class='card'>"

"<div class='section-title'>"
"DATE & TIME SETTINGS"
"</div>"

"<p style='text-align:center;'>"
"Set the current date and time of the school bell."
"</p>"

"<label for='rtc_date'>"
"Date"
"</label>"

"<input "
"type='date' "
"id='rtc_date'>"

"<label for='rtc_time'>"
"Time"
"</label>"

"<input "
"type='time' "
"id='rtc_time'>"

"<button "
"class='add-btn' "
"onclick='setDateTime()'>"
"SET DATE & TIME"
"</button>"

"<div "
"class='message' "
"id='rtc_msg'>"
"</div>"

"</div>"

/* =========================================================
 * ADD NEW BELL
 * ========================================================= */

"<div class='card'>"

"<div class='section-title'>"
"ADD NEW BELL"
"</div>"

"<label for='event'>"
"Event Name"
"</label>"

"<input "
"type='text' "
"id='event' "
"placeholder='Example: Morning Assembly'>"

"<label for='time'>"
"Bell Time"
"</label>"

"<input "
"type='time' "
"id='time'>"

/* =========================================================
 * RINGTONE
 * ========================================================= */

"<label for='ringtone'>"
"Ringtone"
"</label>"

"<select id='ringtone'>"

"<option value='1'>Classic Bell</option>"

"<option value='2'>Long Bell</option>"

"<option value='3'>Double Bell</option>"

"<option value='4'>Emergency Bell</option>"

"</select>"

/* =========================================================
 * REPETITION
 * ========================================================= */

"<label for='repeat'>"
"Repetition"
"</label>"

"<select id='repeat'>"

"<option value='1'>1 time</option>"
"<option value='2'>2 times</option>"
"<option value='3' selected>3 times</option>"
"<option value='4'>4 times</option>"
"<option value='5'>5 times</option>"
"<option value='6'>6 times</option>"
"<option value='7'>7 times</option>"
"<option value='8'>8 times</option>"
"<option value='9'>9 times</option>"
"<option value='10'>10 times</option>"

"</select>"

/* =========================================================
 * DURATION
 * ========================================================= */

"<label for='duration'>"
"Duration (seconds)"
"</label>"

"<select id='duration'>"

"<option value='1'>1 second</option>"
"<option value='2'>2 seconds</option>"
"<option value='3' selected>3 seconds</option>"
"<option value='4'>4 seconds</option>"
"<option value='5'>5 seconds</option>"
"<option value='6'>6 seconds</option>"
"<option value='7'>7 seconds</option>"
"<option value='8'>8 seconds</option>"
"<option value='9'>9 seconds</option>"
"<option value='10'>10 seconds</option>"

"</select>"

"<button "
"class='add-btn' "
"onclick='saveTime()'>"
"ADD BELL"
"</button>"

"<div class='message' id='msg'>"
"</div>"

"</div>"

/* =========================================================
 * BELL SCHEDULE
 * ========================================================= */

"<div class='card'>"

"<div class='section-title'>"
"TODAY'S BELL SCHEDULE"
"</div>"

"<div class='table-container'>"

"<div id='table'>"

"<div style='text-align:center;"
"padding:20px;"
"color:#64748b;'>"
"Loading schedule..."
"</div>"

"</div>"

"</div>"

"</div>"

/* =========================================================
 * SYSTEM STATUS
 * ========================================================= */

"<div class='card'>"

"<div class='section-title'>"
"SYSTEM STATUS"
"</div>"

"<div class='status-row'>"
"<span>Wi-Fi</span>"
"<span class='ok'>Connected</span>"
"</div>"

"<div class='status-row'>"
"<span>RTC</span>"
"<span class='ok'>Working</span>"
"</div>"

"<div class='status-row'>"
"<span>Buzzer</span>"
"<span class='ok'>Ready</span>"
"</div>"

"<div class='status-row'>"
"<span>Web Server</span>"
"<span class='ok'>Running</span>"
"</div>"

"</div>"

/* =========================================================
 * LOGOUT
 * ========================================================= */

"<div style='text-align:center;margin:15px;'>"

"<a href='/logout' "
"style='display:inline-block;"
"padding:10px 18px;"
"background:#dc2626;"
"color:white;"
"text-decoration:none;"
"border-radius:8px;"
"font-weight:bold;'>"

"LOGOUT"

"</a>"

"</div>"

"<div class='footer'>"
"ESP32 Automatic School Bell System"
"</div>"

"</div>"

/* =========================================================
 * JAVASCRIPT
 * ========================================================= */

"<script>"

/* =========================================================
 * SAVE BELL
 * ========================================================= */

"function saveTime(){"

"var t = document.getElementById('time').value;"

"var e = document.getElementById('event').value.trim();"

"var r = document.getElementById('ringtone').value;"

"var repeat = document.getElementById('repeat').value;"

"var duration = document.getElementById('duration').value;"

"var msg = document.getElementById('msg');"

"if(e === '' || t === ''){"

"msg.innerHTML = "
"'Please enter event name and bell time';"

"msg.style.color = '#dc2626';"

"return;"

"}"

/*
 * IMPORTANT:
 *
 * main.c expects:
 *
 * time
 * event
 * ringtone
 * repeat
 * duration
 */

"var url = "
"'/save?time=' + encodeURIComponent(t) + "
"'&event=' + encodeURIComponent(e) + "
"'&ringtone=' + encodeURIComponent(r) + "
"'&repeat=' + encodeURIComponent(repeat) + "
"'&duration=' + encodeURIComponent(duration);"

"console.log('Save URL = ' + url);"

"fetch(url)"

".then(function(response){"

"return response.text();"

"})"

".then(function(data){"

"if(data === 'OK'){"

"msg.innerHTML = 'Bell added successfully';"

"msg.style.color = '#16a34a';"

"}"
"else{"

"msg.innerHTML = data;"

"msg.style.color = '#dc2626';"

"}"

"document.getElementById('event').value = '';"

"document.getElementById('time').value = '';"

"document.getElementById('ringtone').value = '1';"

"document.getElementById('repeat').value = '3';"

"document.getElementById('duration').value = '3';"

"updateTable();"

"setTimeout(function(){"

"msg.innerHTML = '';"

"},3000);"

"})"

".catch(function(error){"

"console.log(error);"

"msg.innerHTML = "
"'Error communicating with ESP32';"

"msg.style.color = '#dc2626';"

"});"

"}"

/* =========================================================
 * DELETE BELL
 * ========================================================= */

"function deleteBell(index){"

"if(!confirm('Delete this bell?')){"

"return;"

"}"

"fetch('/delete?index=' + index)"

".then(function(response){"

"return response.text();"

"})"

".then(function(data){"

"var msg = document.getElementById('msg');"

"if(data === 'OK'){"

"msg.innerHTML = 'Bell deleted successfully';"

"msg.style.color = '#16a34a';"

"}"
"else{"

"msg.innerHTML = data;"

"msg.style.color = '#dc2626';"

"}"

"updateTable();"

"setTimeout(function(){"

"msg.innerHTML = '';"

"},3000);"

"})"

".catch(function(){"

"var msg = document.getElementById('msg');"

"msg.innerHTML = 'Error deleting bell';"

"msg.style.color = '#dc2626';"

"});"

"}"

/* =========================================================
 * UPDATE RTC TIME
 * ========================================================= */

"function updateTime(){"

"fetch('/time')"

".then(function(response){"

"return response.json();"

"})"

".then(function(data){"

"document.getElementById('clock').innerHTML = "
"data.time;"

"document.getElementById('date').innerHTML = "
"data.day + ' ' + data.date;"

"})"

".catch(function(error){"

"console.log(error);"

"document.getElementById('clock').innerHTML = "
"'RTC Error';"

"document.getElementById('date').innerHTML = "
"'Unable to read RTC';"

"});"

"}"

/* =========================================================
 * SET RTC DATE & TIME
 * ========================================================= */

"function setDateTime(){"

"var date = document.getElementById('rtc_date').value;"

"var time = document.getElementById('rtc_time').value;"

"var msg = document.getElementById('rtc_msg');"

"if(date === '' || time === ''){"

"msg.innerHTML = "
"'Please select date and time';"

"msg.style.color = '#dc2626';"

"return;"

"}"

"var url = "
"'/set_datetime?date=' + encodeURIComponent(date) + "
"'&time=' + encodeURIComponent(time);"

"console.log('RTC URL = ' + url);"

"fetch(url)"

".then(function(response){"

"return response.text();"

"})"

".then(function(data){"

"console.log('ESP32 Response = ' + data);"

"if(data === 'OK'){"

"msg.innerHTML = "
"'Date & Time Set Successfully';"

"msg.style.color = '#16a34a';"

"updateTime();"

"}"
"else{"

"msg.innerHTML = data;"

"msg.style.color = '#dc2626';"

"}"

"setTimeout(function(){"

"msg.innerHTML = '';"

"},4000);"

"})"

".catch(function(error){"

"console.log(error);"

"msg.innerHTML = "
"'Failed to set date and time';"

"msg.style.color = '#dc2626';"

"});"

"}"

/* =========================================================
 * UPDATE BELL TABLE
 * ========================================================= */

"function updateTable(){"

"fetch('/get_bells')"

".then(function(response){"

"console.log('GET /get_bells status = ' + response.status);"

"if(!response.ok){"

"return response.text().then(function(text){"

"throw new Error('HTTP ' + response.status + ': ' + text);"

"});"

"}"

"return response.json();"

"})"

".then(function(data){"

"console.log('Schedule data received:', data);"

"var html = '';"

"if(!Array.isArray(data)){"

"throw new Error('Invalid schedule data');"

"}"

"if(data.length === 0){"

"html = '<div style=\"text-align:center;padding:20px;color:#64748b;\">' +"

"'No bells scheduled' +"

"'</div>';"

"}"

"else{"

"html += '<table>';"

"html += '<tr>';"

"html += '<th>Time</th>';"

"html += '<th>Event</th>';"

"html += '<th>Ringtone</th>';"

"html += '<th>Repeat</th>';"

"html += '<th>Duration</th>';"

"html += '<th>Delete</th>';"

"html += '</tr>';"

"for(var i = 0; i < data.length; i++){"

"var item = data[i];"

"var hour = String(item.hour).padStart(2,'0');"

"var minute = String(item.minute).padStart(2,'0');"

"var time = hour + ':' + minute;"

"var ringtone = '';"

"if(item.ringtone == 1){"

"ringtone = 'Classic Bell';"

"}"

"else if(item.ringtone == 2){"

"ringtone = 'Long Bell';"

"}"

"else if(item.ringtone == 3){"

"ringtone = 'Double Bell';"

"}"

"else if(item.ringtone == 4){"

"ringtone = 'Emergency Bell';"

"}"

"else{"

"ringtone = 'Unknown';"

"}"

"html += '<tr>';"

"html += '<td>' + time + '</td>';"

"html += '<td>' + item.event + '</td>';"

"html += '<td>' + ringtone + '</td>';"

"html += '<td>' + item.repeat + ' times</td>';"

"html += '<td>' + item.duration + ' sec</td>';"

"html += '<td>';"

"html += '<button onclick=\"deleteBell(' + item.index + ')\">';"

"html += 'DELETE';"

"html += '</button>';"

"html += '</td>';"

"html += '</tr>';"

"}"

"html += '</table>';"

"}"

"document.getElementById('table').innerHTML = html;"

"findNextBell(data);"

"})"

".catch(function(error){"

"console.error('Schedule loading error:', error);"

"document.getElementById('table').innerHTML ="

"'<div style=\"text-align:center;padding:20px;color:#dc2626;\">' +"

"'Unable to load schedule' +"

"'</div>';"

"});"

"}"








/* =========================================================
 * FIND NEXT BELL
 * ========================================================= */

"function findNextBell(data){"

"var now = new Date();"

"var currentMinutes = "
"now.getHours() * 60 + "
"now.getMinutes() + "
"now.getSeconds() / 60;"

"var nextMinutes = 1441;"

"var nextTime = '';"

"var nextEvent = '';"

"var nextRingtone = '';"

"var nextRepeat = '';"

"var nextDuration = '';"

"for(var i = 0; i < data.length; i++){"

"var item = data[i];"

"var minutes = "
"item.hour * 60 + item.minute;"

"if(minutes > currentMinutes && "
"minutes < nextMinutes){"

"nextMinutes = minutes;"

"nextTime = "
"String(item.hour).padStart(2,'0') + ':' + "
"String(item.minute).padStart(2,'0');"

"nextEvent = item.event;"

"if(item.ringtone == 1){"

"nextRingtone = 'Classic Bell';"

"}"
"else if(item.ringtone == 2){"

"nextRingtone = 'Long Bell';"

"}"
"else if(item.ringtone == 3){"

"nextRingtone = 'Double Bell';"

"}"
"else if(item.ringtone == 4){"

"nextRingtone = 'Emergency Bell';"

"}"

"nextRepeat = item.repeat;"

"nextDuration = item.duration;"

"}"

"}"

"if(nextTime !== ''){"

"document.getElementById('nextTime').innerHTML = "
"nextTime;"

"document.getElementById('nextEvent').innerHTML = "
"nextEvent;"

"document.getElementById('nextInfo').innerHTML = "
"nextRingtone + "
"' | Repeat: ' + "
"nextRepeat + "
"' | Duration: ' + "
"nextDuration + ' sec';"

"}"
"else{"

"document.getElementById('nextTime').innerHTML = "
"'--:--';"

"document.getElementById('nextEvent').innerHTML = "
"'No more bells today';"

"document.getElementById('nextInfo').innerHTML = "
"'Schedule completed';"

"}"

"}"

/* =========================================================
 * INITIAL START
 * ========================================================= */

"updateTime();"

"updateTable();"

"setInterval(updateTime,1000);"

"setInterval(updateTable,5000);"

"</script>"

"</body>"

"</html>";

