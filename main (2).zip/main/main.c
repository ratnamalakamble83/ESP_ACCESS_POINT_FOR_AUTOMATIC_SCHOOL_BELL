
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <stdbool.h>
#include <stdint.h>

#include "freertos/FreeRTOS.h"
#include "freertos/task.h"

#include "esp_log.h"
#include "esp_err.h"
#include "esp_wifi.h"
#include "esp_event.h"
#include "esp_netif.h"
#include "esp_http_server.h"

#include "driver/gpio.h"

#include "eeprom.h"
#include "auth.h"
#include "rtc.h"
#include "html_page.h"

/* =========================================================
 * SETTINGS
 * ========================================================= */

#define TAG                 "SCHOOL_BELL"

#define MAX_BELLS           20

#define BUZZER_PIN          GPIO_NUM_45

#define WIFI_SSID           "ESP32_SCHOOL"
#define WIFI_PASSWORD       "12345678"
#define MAX_STA_CONN        4

#define SESSION_COOKIE      "school_session"

/* =========================================================
 * BELL STRUCTURE
 * ========================================================= */

typedef struct
{
    uint8_t hour;
    uint8_t minute;

    char event[30];

    uint8_t ringtone;

    uint8_t repeat;       /* 1 to 10 */
    uint8_t duration;     /* 1 to 10 seconds */

} BellTime;

/* =========================================================
 * GLOBAL VARIABLES
 * ========================================================= */

static BellTime bell[MAX_BELLS];

static int total_bells = 0;

static httpd_handle_t server = NULL;

/*
 * Used to prevent the same bell from ringing
 * continuously during the same minute.
 */
static int last_ring_hour = -1;
static int last_ring_minute = -1;

/* =========================================================
 * DAY NAMES
 * ========================================================= */

static const char *day_name[] =
{
    "",
    "Sunday",
    "Monday",
    "Tuesday",
    "Wednesday",
    "Thursday",
    "Friday",
    "Saturday"
};

/* =========================================================
 * URL DECODE
 * ========================================================= */

static void url_decode(char *dst, const char *src, size_t dst_size)
{
    size_t i = 0;
    size_t j = 0;

    while (src[i] != '\0' && j < dst_size - 1)
    {
        if (src[i] == '%')
        {
            if (src[i + 1] != '\0' &&
                src[i + 2] != '\0')
            {
                char hex[3];

                hex[0] = src[i + 1];
                hex[1] = src[i + 2];
                hex[2] = '\0';

                char *endptr;

                long value = strtol(hex, &endptr, 16);

                if (*endptr == '\0')
                {
                    dst[j++] = (char)value;
                    i += 3;
                    continue;
                }
            }
        }

        if (src[i] == '+')
        {
            dst[j++] = ' ';
        }
        else
        {
            dst[j++] = src[i];
        }

        i++;
    }

    dst[j] = '\0';
}

/* =========================================================
 * EEPROM SAVE
 * ========================================================= */

static void save_bells_to_eeprom(void)
{
    if (total_bells < 0)
    {
        total_bells = 0;
    }

    if (total_bells > MAX_BELLS)
    {
        total_bells = MAX_BELLS;
    }

    esp_err_t ret = eeprom_save_bells(
        (EEPROM_BellTime *)bell,
        (uint8_t)total_bells
    );

    if (ret == ESP_OK)
    {
        ESP_LOGI(
            TAG,
            "Bell schedule saved to NVS. Total bells = %d",
            total_bells
        );
    }
    else
    {
        ESP_LOGE(
            TAG,
            "Failed to save bells: %s",
            esp_err_to_name(ret)
        );
    }
}

/* =========================================================
 * EEPROM LOAD
 * ========================================================= */

static void load_bells_from_eeprom(void)
{
    uint8_t count = 0;

    esp_err_t ret = eeprom_load_bells(
        (EEPROM_BellTime *)bell,
        &count
    );

    if (ret == ESP_OK)
    {
        total_bells = count;

        if (total_bells > MAX_BELLS)
        {
            total_bells = MAX_BELLS;
        }

        ESP_LOGI(
            TAG,
            "Loaded %d bells from NVS",
            total_bells
        );

        for (int i = 0; i < total_bells; i++)
        {
            ESP_LOGI(
                TAG,
                "Bell %d: %02d:%02d | %s | ringtone=%d | repeat=%d | duration=%d",
                i,
                bell[i].hour,
                bell[i].minute,
                bell[i].event,
                bell[i].ringtone,
                bell[i].repeat,
                bell[i].duration
            );
        }
    }
    else
    {
        total_bells = 0;

        ESP_LOGW(
            TAG,
            "No bell schedule loaded: %s",
            esp_err_to_name(ret)
        );
    }
}

/* =========================================================
 * BUZZER RINGTONE
 * ========================================================= */

static void play_ringtone(
    uint8_t type,
    uint8_t repeat,
    uint8_t duration
)
{
    /*
     * Safety limits
     */

    if (repeat < 1)
    {
        repeat = 1;
    }

    if (repeat > 10)
    {
        repeat = 10;
    }

    if (duration < 1)
    {
        duration = 1;
    }

    if (duration > 10)
    {
        duration = 10;
    }

    ESP_LOGI(
        TAG,
        "Playing ringtone=%d repeat=%d duration=%d sec",
        type,
        repeat,
        duration
    );

    for (uint8_t r = 0; r < repeat; r++)
    {
        switch (type)
        {
            /* -------------------------------------------------
             * 1 = CLASSIC BELL
             * ------------------------------------------------- */

            case 1:

                gpio_set_level(BUZZER_PIN, 1);

                vTaskDelay(
                    pdMS_TO_TICKS(duration * 1000)
                );

                gpio_set_level(BUZZER_PIN, 0);

                break;


            /* -------------------------------------------------
             * 2 = LONG BELL
             * ------------------------------------------------- */

            case 2:

                gpio_set_level(BUZZER_PIN, 1);

                vTaskDelay(
                    pdMS_TO_TICKS(duration * 1000)
                );

                gpio_set_level(BUZZER_PIN, 0);

                break;


            /* -------------------------------------------------
             * 3 = DOUBLE BELL
             * ------------------------------------------------- */

            case 3:

                gpio_set_level(BUZZER_PIN, 1);

                vTaskDelay(
                    pdMS_TO_TICKS(duration * 500)
                );

                gpio_set_level(BUZZER_PIN, 0);

                vTaskDelay(
                    pdMS_TO_TICKS(300)
                );

                gpio_set_level(BUZZER_PIN, 1);

                vTaskDelay(
                    pdMS_TO_TICKS(duration * 500)
                );

                gpio_set_level(BUZZER_PIN, 0);

                break;


            /* -------------------------------------------------
             * 4 = EMERGENCY BELL
             * ------------------------------------------------- */

            case 4:

                for (int j = 0; j < 3; j++)
                {
                    gpio_set_level(BUZZER_PIN, 1);

                    vTaskDelay(
                        pdMS_TO_TICKS(duration * 100)
                    );

                    gpio_set_level(BUZZER_PIN, 0);

                    vTaskDelay(
                        pdMS_TO_TICKS(200)
                    );
                }

                break;


            /* -------------------------------------------------
             * DEFAULT
             * ------------------------------------------------- */

            default:

                gpio_set_level(BUZZER_PIN, 1);

                vTaskDelay(
                    pdMS_TO_TICKS(duration * 1000)
                );

                gpio_set_level(BUZZER_PIN, 0);

                break;
        }

        /*
         * Gap between repetitions
         */

        if (r < repeat - 1)
        {
            vTaskDelay(
                pdMS_TO_TICKS(300)
            );
        }
    }

    gpio_set_level(BUZZER_PIN, 0);
}

/* =========================================================
 * AUTHENTICATION
 * ========================================================= */

static bool request_is_authenticated(httpd_req_t *req)
{
    char cookie[256];

    size_t cookie_len = httpd_req_get_hdr_value_len(
        req,
        "Cookie"
    );

    if (cookie_len == 0)
    {
        return false;
    }

    if (cookie_len >= sizeof(cookie))
    {
        return false;
    }

    if (httpd_req_get_hdr_value_str(
            req,
            "Cookie",
            cookie,
            sizeof(cookie)) != ESP_OK)
    {
        return false;
    }

    char *session_start = strstr(
        cookie,
        SESSION_COOKIE "="
    );

    if (session_start == NULL)
    {
        return false;
    }

    session_start += strlen(
        SESSION_COOKIE "="
    );

    char session[128];

    size_t i = 0;

    while (
        session_start[i] != '\0' &&
        session_start[i] != ';' &&
        i < sizeof(session) - 1
    )
    {
        session[i] = session_start[i];
        i++;
    }

    session[i] = '\0';

    if (auth_check_session(session))
    {
        return true;
    }

    return false;
}

/* =========================================================
 * LOGIN PAGE
 * ========================================================= */

static const char login_page[] =
"<!DOCTYPE html>"
"<html>"
"<head>"
"<meta name='viewport' content='width=device-width,initial-scale=1'>"
"<title>School Bell Login</title>"
"<style>"
"body{font-family:Arial;text-align:center;background:#f2f2f2;padding:30px;}"
".box{max-width:400px;margin:auto;background:white;padding:25px;border-radius:10px;}"
"input{width:90%;padding:12px;margin:10px 0;}"
"button{padding:12px 25px;}"
"</style>"
"</head>"
"<body>"
"<div class='box'>"
"<h2>Automatic School Bell</h2>"
"<h3>Login</h3>"
"<form action='/login_check'>"
"<input type='password' name='password' placeholder='Enter password' required>"
"<br>"
"<button type='submit'>LOGIN</button>"
"</form>"
"</div>"
"</body>"
"</html>";

/* =========================================================
 * SET PASSWORD PAGE
 * ========================================================= */

static const char set_password_page[] =
"<!DOCTYPE html>"
"<html>"
"<head>"
"<meta name='viewport' content='width=device-width,initial-scale=1'>"
"<title>Set Password</title>"
"<style>"
"body{font-family:Arial;text-align:center;background:#f2f2f2;padding:30px;}"
".box{max-width:400px;margin:auto;background:white;padding:25px;border-radius:10px;}"
"input{width:90%;padding:12px;margin:10px 0;}"
"button{padding:12px 25px;}"
"</style>"
"</head>"
"<body>"
"<div class='box'>"
"<h2>Automatic School Bell</h2>"
"<h3>Create Password</h3>"
"<form action='/set_password'>"
"<input type='password' name='password' placeholder='New password' required>"
"<br>"
"<input type='password' name='confirm' placeholder='Confirm password' required>"
"<br>"
"<button type='submit'>SET PASSWORD</button>"
"</form>"
"<p>Minimum 4 characters</p>"
"</div>"
"</body>"
"</html>";

/* =========================================================
 * ROOT HANDLER
 * ========================================================= */

static esp_err_t root_handler(httpd_req_t *req)
{
    /*
     * First boot:
     * password does not exist.
     */

    if (!auth_password_is_set())
    {
        httpd_resp_set_type(
            req,
            "text/html"
        );

        httpd_resp_send(
            req,
            set_password_page,
            HTTPD_RESP_USE_STRLEN
        );

        return ESP_OK;
    }

    /*
     * Password exists but user is not logged in.
     */

    if (!request_is_authenticated(req))
    {
        httpd_resp_set_type(
            req,
            "text/html"
        );

        httpd_resp_send(
            req,
            login_page,
            HTTPD_RESP_USE_STRLEN
        );

        return ESP_OK;
    }

    /*
     * User authenticated.
     */

    httpd_resp_set_type(
        req,
        "text/html"
    );

    httpd_resp_send(
        req,
        html_page,
        HTTPD_RESP_USE_STRLEN
    );

    return ESP_OK;
}

/* =========================================================
 * LOGIN HANDLER
 * ========================================================= */

static esp_err_t login_handler(httpd_req_t *req)
{
    char query[256];

    if (httpd_req_get_url_query_str(
            req,
            query,
            sizeof(query)) != ESP_OK)
    {
        httpd_resp_send_err(
            req,
            HTTPD_400_BAD_REQUEST,
            "Password missing"
        );

        return ESP_FAIL;
    }

    char encoded_password[128];

    if (httpd_query_key_value(
            query,
            "password",
            encoded_password,
            sizeof(encoded_password)) != ESP_OK)
    {
        httpd_resp_send_err(
            req,
            HTTPD_400_BAD_REQUEST,
            "Password missing"
        );

        return ESP_FAIL;
    }

    char password[128];

    url_decode(
        password,
        encoded_password,
        sizeof(password)
    );

    if (!auth_check_password(password))
    {
        httpd_resp_send_err(
            req,
            HTTPD_401_UNAUTHORIZED,
            "Incorrect password"
        );

        return ESP_FAIL;
    }

    char session[128];

    if (!auth_create_session(
            session,
            sizeof(session)))
    {
        httpd_resp_send_err(
            req,
            HTTPD_500_INTERNAL_SERVER_ERROR,
            "Could not create session"
        );

        return ESP_FAIL;
    }

    char cookie[180];

    snprintf(
        cookie,
        sizeof(cookie),
        SESSION_COOKIE "=%s; Path=/; HttpOnly",
        session
    );

    httpd_resp_set_hdr(
        req,
        "Set-Cookie",
        cookie
    );

    httpd_resp_set_status(
        req,
        "302 Found"
    );

    httpd_resp_set_hdr(
        req,
        "Location",
        "/"
    );

    httpd_resp_send(
        req,
        NULL,
        0
    );

    ESP_LOGI(
        TAG,
        "User logged in"
    );

    return ESP_OK;
}

/* =========================================================
 * SET PASSWORD HANDLER
 * ========================================================= */

static esp_err_t set_password_handler(httpd_req_t *req)
{
    /*
     * Password should only be created once.
     */

    if (auth_password_is_set())
    {
        httpd_resp_send_err(
            req,
            HTTPD_403_FORBIDDEN,
            "Password already configured"
        );

        return ESP_FAIL;
    }

    char query[300];

    if (httpd_req_get_url_query_str(
            req,
            query,
            sizeof(query)) != ESP_OK)
    {
        httpd_resp_send_err(
            req,
            HTTPD_400_BAD_REQUEST,
            "Invalid request"
        );

        return ESP_FAIL;
    }

    char encoded_password[128];
    char encoded_confirm[128];

    if (httpd_query_key_value(
            query,
            "password",
            encoded_password,
            sizeof(encoded_password)) != ESP_OK)
    {
        httpd_resp_send_err(
            req,
            HTTPD_400_BAD_REQUEST,
            "Password missing"
        );

        return ESP_FAIL;
    }

    if (httpd_query_key_value(
            query,
            "confirm",
            encoded_confirm,
            sizeof(encoded_confirm)) != ESP_OK)
    {
        httpd_resp_send_err(
            req,
            HTTPD_400_BAD_REQUEST,
            "Confirm password missing"
        );

        return ESP_FAIL;
    }

    char password[128];
    char confirm[128];

    url_decode(
        password,
        encoded_password,
        sizeof(password)
    );

    url_decode(
        confirm,
        encoded_confirm,
        sizeof(confirm)
    );

    if (strlen(password) < 4)
    {
        httpd_resp_send_err(
            req,
            HTTPD_400_BAD_REQUEST,
            "Password must contain at least 4 characters"
        );

        return ESP_FAIL;
    }

    if (strcmp(password, confirm) != 0)
    {
        httpd_resp_send_err(
            req,
            HTTPD_400_BAD_REQUEST,
            "Passwords do not match"
        );

        return ESP_FAIL;
    }

    esp_err_t ret = auth_set_password(
        password
    );

    if (ret != ESP_OK)
    {
        httpd_resp_send_err(
            req,
            HTTPD_500_INTERNAL_SERVER_ERROR,
            "Failed to save password"
        );

        return ret;
    }

    httpd_resp_set_status(
        req,
        "302 Found"
    );

    httpd_resp_set_hdr(
        req,
        "Location",
        "/"
    );

    httpd_resp_send(
        req,
        NULL,
        0
    );

    ESP_LOGI(
        TAG,
        "Password configured successfully"
    );

    return ESP_OK;
}

/* =========================================================
 * LOGOUT HANDLER
 * ========================================================= */

static esp_err_t logout_handler(httpd_req_t *req)
{
    auth_logout();

    httpd_resp_set_hdr(
        req,
        "Set-Cookie",
        SESSION_COOKIE "=; Path=/; Max-Age=0"
    );

    httpd_resp_set_status(
        req,
        "302 Found"
    );

    httpd_resp_set_hdr(
        req,
        "Location",
        "/"
    );

    httpd_resp_send(
        req,
        NULL,
        0
    );

    return ESP_OK;
}

/* =========================================================
 * RTC TIME HANDLER
 * ========================================================= */

static esp_err_t time_handler(httpd_req_t *req)
{
    if (!request_is_authenticated(req))
    {
        httpd_resp_send_err(
            req,
            HTTPD_401_UNAUTHORIZED,
            "Unauthorized"
        );

        return ESP_FAIL;
    }

    rtc_time_t now;

    esp_err_t ret = rtc_get_datetime(
        &now
    );

    if (ret != ESP_OK)
    {
        httpd_resp_send_err(
            req,
            HTTPD_500_INTERNAL_SERVER_ERROR,
            "RTC read failed"
        );

        return ret;
    }

    char response[200];

    const char *day = "";

    if (now.day >= 1 && now.day <= 7)
    {
        day = day_name[now.day];
    }

    snprintf(
        response,
        sizeof(response),
        "{\"day\":\"%s\",\"date\":\"%02d/%02d/20%02d\",\"time\":\"%02d:%02d:%02d\"}",
        day,
        now.date,
        now.month,
        now.year,
        now.hour,
        now.minute,
        now.second
    );

    httpd_resp_set_type(
        req,
        "application/json"
    );

    httpd_resp_send(
        req,
        response,
        HTTPD_RESP_USE_STRLEN
    );

    return ESP_OK;
}

/* =========================================================
 * SET DATE AND TIME HANDLER
 * ========================================================= */

static esp_err_t set_datetime_handler(httpd_req_t *req)
{
    if (!request_is_authenticated(req))
    {
        httpd_resp_send_err(
            req,
            HTTPD_401_UNAUTHORIZED,
            "Unauthorized"
        );

        return ESP_FAIL;
    }

    char query[300];

    if (httpd_req_get_url_query_str(
            req,
            query,
            sizeof(query)) != ESP_OK)
    {
        httpd_resp_send_err(
            req,
            HTTPD_400_BAD_REQUEST,
            "Invalid request"
        );

        return ESP_FAIL;
    }

    char encoded_date[32];
    char encoded_time[32];

    if (httpd_query_key_value(
            query,
            "date",
            encoded_date,
            sizeof(encoded_date)) != ESP_OK)
    {
        httpd_resp_send_err(
            req,
            HTTPD_400_BAD_REQUEST,
            "Date missing"
        );

        return ESP_FAIL;
    }

    if (httpd_query_key_value(
            query,
            "time",
            encoded_time,
            sizeof(encoded_time)) != ESP_OK)
    {
        httpd_resp_send_err(
            req,
            HTTPD_400_BAD_REQUEST,
            "Time missing"
        );

        return ESP_FAIL;
    }

    char decoded_date[32];
    char decoded_time[32];

    url_decode(
        decoded_date,
        encoded_date,
        sizeof(decoded_date)
    );

    url_decode(
        decoded_time,
        encoded_time,
        sizeof(decoded_time)
    );

    int year;
    int month;
    int date;

    if (sscanf(
            decoded_date,
            "%d-%d-%d",
            &year,
            &month,
            &date) != 3)
    {
        httpd_resp_send_err(
            req,
            HTTPD_400_BAD_REQUEST,
            "Invalid date"
        );

        return ESP_FAIL;
    }

    int hour;
    int minute;

    if (sscanf(
            decoded_time,
            "%d:%d",
            &hour,
            &minute) != 2)
    {
        httpd_resp_send_err(
            req,
            HTTPD_400_BAD_REQUEST,
            "Invalid time"
        );

        return ESP_FAIL;
    }

    /*
     * Basic validation
     */

    if (year < 2000 || year > 2099 ||
        month < 1 || month > 12 ||
        date < 1 || date > 31 ||
        hour < 0 || hour > 23 ||
        minute < 0 || minute > 59)
    {
        httpd_resp_send_err(
            req,
            HTTPD_400_BAD_REQUEST,
            "Invalid date or time values"
        );

        return ESP_FAIL;
    }

    /*
     * Calculate day of week.
     *
     * Result:
     * 1 = Sunday
     * 2 = Monday
     * ...
     * 7 = Saturday
     */

    int y = year;
    int m = month;

    if (m < 3)
    {
        m += 12;
        y--;
    }

    int k = y % 100;
    int j = y / 100;

    int h =
        (
            date +
            (13 * (m + 1)) / 5 +
            k +
            k / 4 +
            j / 4 +
            5 * j
        ) % 7;

    int day = ((h + 6) % 7) + 1;

    rtc_time_t set_time =
    {
        .year = (uint8_t)(year - 2000),
        .month = (uint8_t)month,
        .date = (uint8_t)date,
        .day = (uint8_t)day,
        .hour = (uint8_t)hour,
        .minute = (uint8_t)minute,
        .second = 0
    };

    esp_err_t ret = rtc_set_datetime(
        &set_time
    );

    if (ret != ESP_OK)
    {
        httpd_resp_send_err(
            req,
            HTTPD_500_INTERNAL_SERVER_ERROR,
            "RTC write failed"
        );

        return ret;
    }

    ESP_LOGI(
        TAG,
        "Date/time set: %04d-%02d-%02d %02d:%02d",
        year,
        month,
        date,
        hour,
        minute
    );

    httpd_resp_set_type(
        req,
        "text/plain"
    );

    httpd_resp_send(
        req,
        "OK",
        HTTPD_RESP_USE_STRLEN
    );

    return ESP_OK;
}

/* =========================================================
 * SAVE BELL HANDLER
 * ========================================================= */

static esp_err_t save_handler(httpd_req_t *req)
{
    if (!request_is_authenticated(req))
    {
        httpd_resp_send_err(
            req,
            HTTPD_401_UNAUTHORIZED,
            "Unauthorized"
        );

        return ESP_FAIL;
    }

    if (total_bells >= MAX_BELLS)
    {
        httpd_resp_send_err(
            req,
            HTTPD_400_BAD_REQUEST,
            "Maximum 20 bells reached"
        );

        return ESP_FAIL;
    }

    char query[500];

    if (httpd_req_get_url_query_str(
            req,
            query,
            sizeof(query)) != ESP_OK)
    {
        httpd_resp_send_err(
            req,
            HTTPD_400_BAD_REQUEST,
            "Invalid request"
        );

        return ESP_FAIL;
    }

    char encoded_time[32];
    char encoded_event[100];
    char ringtone_str[10];
    char repeat_str[10];
    char duration_str[10];

    if (httpd_query_key_value(
            query,
            "time",
            encoded_time,
            sizeof(encoded_time)) != ESP_OK)
    {
        httpd_resp_send_err(
            req,
            HTTPD_400_BAD_REQUEST,
            "Time missing"
        );

        return ESP_FAIL;
    }

    if (httpd_query_key_value(
            query,
            "event",
            encoded_event,
            sizeof(encoded_event)) != ESP_OK)
    {
        httpd_resp_send_err(
            req,
            HTTPD_400_BAD_REQUEST,
            "Event missing"
        );

        return ESP_FAIL;
    }

    if (httpd_query_key_value(
            query,
            "ringtone",
            ringtone_str,
            sizeof(ringtone_str)) != ESP_OK)
    {
        strcpy(ringtone_str, "1");
    }

    if (httpd_query_key_value(
            query,
            "repeat",
            repeat_str,
            sizeof(repeat_str)) != ESP_OK)
    {
        strcpy(repeat_str, "1");
    }

    if (httpd_query_key_value(
            query,
            "duration",
            duration_str,
            sizeof(duration_str)) != ESP_OK)
    {
        strcpy(duration_str, "1");
    }

    char decoded_time[32];
    char decoded_event[100];

    url_decode(
        decoded_time,
        encoded_time,
        sizeof(decoded_time)
    );

    url_decode(
        decoded_event,
        encoded_event,
        sizeof(decoded_event)
    );

    int hour;
    int minute;

    if (sscanf(
            decoded_time,
            "%d:%d",
            &hour,
            &minute) != 2)
    {
        httpd_resp_send_err(
            req,
            HTTPD_400_BAD_REQUEST,
            "Invalid time"
        );

        return ESP_FAIL;
    }

    int ringtone = atoi(ringtone_str);
    int repeat = atoi(repeat_str);
    int duration = atoi(duration_str);

    /*
     * Validate values
     */

    if (hour < 0 || hour > 23 ||
        minute < 0 || minute > 59)
    {
        httpd_resp_send_err(
            req,
            HTTPD_400_BAD_REQUEST,
            "Invalid time"
        );

        return ESP_FAIL;
    }

    if (ringtone < 1 || ringtone > 4)
    {
        ringtone = 1;
    }

    if (repeat < 1 || repeat > 10)
    {
        httpd_resp_send_err(
            req,
            HTTPD_400_BAD_REQUEST,
            "Repeat must be 1 to 10"
        );

        return ESP_FAIL;
    }

    if (duration < 1 || duration > 10)
    {
        httpd_resp_send_err(
            req,
            HTTPD_400_BAD_REQUEST,
            "Duration must be 1 to 10 seconds"
        );

        return ESP_FAIL;
    }

    /*
     * Fill new bell
     */

    bell[total_bells].hour =
        (uint8_t)hour;

    bell[total_bells].minute =
        (uint8_t)minute;

    strncpy(
        bell[total_bells].event,
        decoded_event,
        sizeof(bell[total_bells].event) - 1
    );

    bell[total_bells].event[
        sizeof(bell[total_bells].event) - 1
    ] = '\0';

    bell[total_bells].ringtone =
        (uint8_t)ringtone;

    bell[total_bells].repeat =
        (uint8_t)repeat;

    bell[total_bells].duration =
        (uint8_t)duration;

    ESP_LOGI(
        TAG,
        "Adding bell: %02d:%02d | %s | ringtone=%d | repeat=%d | duration=%d",
        hour,
        minute,
        bell[total_bells].event,
        ringtone,
        repeat,
        duration
    );

    total_bells++;

    /*
     * Save entire schedule to NVS
     */

    save_bells_to_eeprom();

    httpd_resp_set_type(
        req,
        "text/plain"
    );

    httpd_resp_send(
        req,
        "OK",
        HTTPD_RESP_USE_STRLEN
    );

    return ESP_OK;
}

/* =========================================================
 * DELETE BELL HANDLER
 * ========================================================= */

static esp_err_t delete_handler(httpd_req_t *req)
{
    if (!request_is_authenticated(req))
    {
        httpd_resp_send_err(
            req,
            HTTPD_401_UNAUTHORIZED,
            "Unauthorized"
        );

        return ESP_FAIL;
    }

    char query[100];

    if (httpd_req_get_url_query_str(
            req,
            query,
            sizeof(query)) != ESP_OK)
    {
        httpd_resp_send_err(
            req,
            HTTPD_400_BAD_REQUEST,
            "Index missing"
        );

        return ESP_FAIL;
    }

    char index_str[10];

    if (httpd_query_key_value(
            query,
            "index",
            index_str,
            sizeof(index_str)) != ESP_OK)
    {
        httpd_resp_send_err(
            req,
            HTTPD_400_BAD_REQUEST,
            "Index missing"
        );

        return ESP_FAIL;
    }

    int index = atoi(index_str);

    if (index < 0 || index >= total_bells)
    {
        httpd_resp_send_err(
            req,
            HTTPD_400_BAD_REQUEST,
            "Invalid bell index"
        );

        return ESP_FAIL;
    }

    ESP_LOGI(
        TAG,
        "Deleting bell index %d",
        index
    );

    /*
     * Shift remaining bells
     */

    for (int i = index; i < total_bells - 1; i++)
    {
        bell[i] = bell[i + 1];
    }

    total_bells--;

    /*
     * Save updated schedule
     */

    save_bells_to_eeprom();

    httpd_resp_set_type(
        req,
        "text/plain"
    );

    httpd_resp_send(
        req,
        "OK",
        HTTPD_RESP_USE_STRLEN
    );

    return ESP_OK;
}

/* =========================================================
 * GET BELLS HANDLER
 * ========================================================= */

static esp_err_t get_bells_handler(httpd_req_t *req)

{
	ESP_LOGI(TAG, "GET /get_bells request received");
    if (!request_is_authenticated(req))
    {
        httpd_resp_send_err(
            req,
            HTTPD_401_UNAUTHORIZED,
            "Unauthorized"
        );

        return ESP_FAIL;
    }

    /*
     * Maximum response size.
     */

    char response[6000];

    int pos = 0;

    pos += snprintf(
        response + pos,
        sizeof(response) - pos,
        "["
    );

    for (int i = 0; i < total_bells; i++)
    {
        /*
         * Replace quotes in event with apostrophe
         * to keep JSON valid.
         */

        char event[30];

        strncpy(
            event,
            bell[i].event,
            sizeof(event) - 1
        );

        event[sizeof(event) - 1] = '\0';

        for (int j = 0; event[j] != '\0'; j++)
        {
            if (event[j] == '"')
            {
                event[j] = '\'';
            }
        }

        pos += snprintf(
            response + pos,
            sizeof(response) - pos,
            "{"
            "\"index\":%d,"
            "\"hour\":%d,"
            "\"minute\":%d,"
            "\"event\":\"%s\","
            "\"ringtone\":%d,"
            "\"repeat\":%d,"
            "\"duration\":%d"
            "}%s",
            i,
            bell[i].hour,
            bell[i].minute,
            event,
            bell[i].ringtone,
            bell[i].repeat,
            bell[i].duration,
            (i < total_bells - 1) ? "," : ""
        );

        if (pos >= sizeof(response) - 100)
        {
            break;
        }
    }

    pos += snprintf(
        response + pos,
        sizeof(response) - pos,
        "]"
    );

    httpd_resp_set_type(
        req,
        "application/json"
    );

    httpd_resp_send(
        req,
        response,
        HTTPD_RESP_USE_STRLEN
    );

    return ESP_OK;
}

/* =========================================================
 * WIFI EVENT HANDLER
 * ========================================================= */

static void wifi_event_handler(
    void *arg,
    esp_event_base_t event_base,
    int32_t event_id,
    void *event_data
)
{
    if (event_id == WIFI_EVENT_AP_STACONNECTED)
    {
        wifi_event_ap_staconnected_t *event =
            (wifi_event_ap_staconnected_t *)event_data;

        ESP_LOGI(
            TAG,
            "Station connected. AID=%d",
            event->aid
        );
    }

    else if (event_id == WIFI_EVENT_AP_STADISCONNECTED)
    {
        wifi_event_ap_stadisconnected_t *event =
            (wifi_event_ap_stadisconnected_t *)event_data;

        ESP_LOGI(
            TAG,
            "Station disconnected. AID=%d",
            event->aid
        );
    }
}

/* =========================================================
 * WIFI ACCESS POINT
 * ========================================================= */

static void wifi_init_softap(void)
{
    ESP_ERROR_CHECK(
        esp_netif_init()
    );

    ESP_ERROR_CHECK(
        esp_event_loop_create_default()
    );

    esp_netif_create_default_wifi_ap();

    wifi_init_config_t cfg =
        WIFI_INIT_CONFIG_DEFAULT();

    ESP_ERROR_CHECK(
        esp_wifi_init(&cfg)
    );

    ESP_ERROR_CHECK(
        esp_event_handler_instance_register(
            WIFI_EVENT,
            ESP_EVENT_ANY_ID,
            &wifi_event_handler,
            NULL,
            NULL
        )
    );

    wifi_config_t wifi_config =
    {
        .ap =
        {
            .ssid = WIFI_SSID,
            .ssid_len = strlen(WIFI_SSID),
            .channel = 1,
            .password = WIFI_PASSWORD,
            .max_connection = MAX_STA_CONN,
            .authmode = WIFI_AUTH_WPA2_PSK
        }
    };

    if (strlen(WIFI_PASSWORD) == 0)
    {
        wifi_config.ap.authmode =
            WIFI_AUTH_OPEN;
    }

    ESP_ERROR_CHECK(
        esp_wifi_set_mode(
            WIFI_MODE_AP
        )
    );

    ESP_ERROR_CHECK(
        esp_wifi_set_config(
            WIFI_IF_AP,
            &wifi_config
        )
    );

    ESP_ERROR_CHECK(
        esp_wifi_start()
    );

    ESP_LOGI(
        TAG,
        "WiFi Access Point Started"
    );

    ESP_LOGI(
        TAG,
        "SSID: %s",
        WIFI_SSID
    );

    ESP_LOGI(
        TAG,
        "Password: %s",
        WIFI_PASSWORD
    );

    ESP_LOGI(
        TAG,
        "Open browser: http://192.168.4.1"
    );
}

/* =========================================================
 * HTTP SERVER
 * ========================================================= */

static void start_webserver(void)
{
    httpd_config_t config =
        HTTPD_DEFAULT_CONFIG();

    config.max_uri_handlers = 20;

    if (httpd_start(
            &server,
            &config) != ESP_OK)
    {
        ESP_LOGE(
            TAG,
            "Failed to start HTTP server"
        );

        return;
    }

    /* -----------------------------------------------------
     * ROOT
     * ----------------------------------------------------- */

    httpd_uri_t root_uri =
    {
        .uri = "/",
        .method = HTTP_GET,
        .handler = root_handler,
        .user_ctx = NULL
    };

    httpd_register_uri_handler(
        server,
        &root_uri
    );


    /* -----------------------------------------------------
     * LOGIN
     * ----------------------------------------------------- */

    httpd_uri_t login_uri =
    {
        .uri = "/login_check",
        .method = HTTP_GET,
        .handler = login_handler,
        .user_ctx = NULL
    };

    httpd_register_uri_handler(
        server,
        &login_uri
    );


    /* -----------------------------------------------------
     * SET PASSWORD
     * ----------------------------------------------------- */

    httpd_uri_t set_password_uri =
    {
        .uri = "/set_password",
        .method = HTTP_GET,
        .handler = set_password_handler,
        .user_ctx = NULL
    };

    httpd_register_uri_handler(
        server,
        &set_password_uri
    );


    /* -----------------------------------------------------
     * LOGOUT
     * ----------------------------------------------------- */

    httpd_uri_t logout_uri =
    {
        .uri = "/logout",
        .method = HTTP_GET,
        .handler = logout_handler,
        .user_ctx = NULL
    };

    httpd_register_uri_handler(
        server,
        &logout_uri
    );


    /* -----------------------------------------------------
     * CURRENT RTC TIME
     * ----------------------------------------------------- */

    httpd_uri_t time_uri =
    {
        .uri = "/time",
        .method = HTTP_GET,
        .handler = time_handler,
        .user_ctx = NULL
    };

    httpd_register_uri_handler(
        server,
        &time_uri
    );


    /* -----------------------------------------------------
     * SET RTC DATE/TIME
     * ----------------------------------------------------- */

    httpd_uri_t set_datetime_uri =
    {
        .uri = "/set_datetime",
        .method = HTTP_GET,
        .handler = set_datetime_handler,
        .user_ctx = NULL
    };

    httpd_register_uri_handler(
        server,
        &set_datetime_uri
    );


    /* -----------------------------------------------------
     * ADD BELL
     * ----------------------------------------------------- */

    httpd_uri_t save_uri =
    {
        .uri = "/save",
        .method = HTTP_GET,
        .handler = save_handler,
        .user_ctx = NULL
    };

    httpd_register_uri_handler(
        server,
        &save_uri
    );


    /* -----------------------------------------------------
     * DELETE BELL
     * ----------------------------------------------------- */

    httpd_uri_t delete_uri =
    {
        .uri = "/delete",
        .method = HTTP_GET,
        .handler = delete_handler,
        .user_ctx = NULL
    };

    httpd_register_uri_handler(
        server,
        &delete_uri
    );


    /* -----------------------------------------------------
     * GET ALL BELLS
     * ----------------------------------------------------- */

    httpd_uri_t get_bells_uri =
    {
        .uri = "/get_bells",
        .method = HTTP_GET,
        .handler = get_bells_handler,
        .user_ctx = NULL
    };

    httpd_register_uri_handler(
        server,
        &get_bells_uri
    );

    ESP_LOGI(
        TAG,
        "HTTP Server Started"
    );
}

/* =========================================================
 * BELL TASK
 * ========================================================= */

static void bell_task(void *pvParameters)
{
    (void)pvParameters;

    while (1)
    {
        rtc_time_t now;

        esp_err_t ret =
            rtc_get_datetime(&now);

        if (ret == ESP_OK)
        {
            /*
             * Check every saved bell.
             */

            for (int i = 0; i < total_bells; i++)
            {
                if (bell[i].hour == now.hour &&
                    bell[i].minute == now.minute)
                {
                    /*
                     * Prevent ringing continuously
                     * during the same minute.
                     */

                    if (last_ring_hour == now.hour &&
                        last_ring_minute == now.minute)
                    {
                        continue;
                    }

                    last_ring_hour = now.hour;
                    last_ring_minute = now.minute;

                    ESP_LOGI(
                        TAG,
                        "BELL TRIGGERED"
                    );

                    ESP_LOGI(
                        TAG,
                        "Time: %02d:%02d",
                        bell[i].hour,
                        bell[i].minute
                    );

                    ESP_LOGI(
                        TAG,
                        "Event: %s",
                        bell[i].event
                    );

                    ESP_LOGI(
                        TAG,
                        "Ringtone: %d",
                        bell[i].ringtone
                    );

                    ESP_LOGI(
                        TAG,
                        "Repeat: %d",
                        bell[i].repeat
                    );

                    ESP_LOGI(
                        TAG,
                        "Duration: %d sec",
                        bell[i].duration
                    );

                    play_ringtone(
                        bell[i].ringtone,
                        bell[i].repeat,
                        bell[i].duration
                    );

                    /*
                     * Only one bell should be triggered
                     * for this minute.
                     */

                    break;
                }
            }
        }
        else
        {
            ESP_LOGE(
                TAG,
                "RTC read failed: %s",
                esp_err_to_name(ret)
            );
        }

        /*
         * Check RTC every second.
         */

        vTaskDelay(
            pdMS_TO_TICKS(1000)
        );
    }
}

/* =========================================================
 * BUZZER INITIALIZATION
 * ========================================================= */

static void buzzer_init(void)
{
    gpio_config_t io_conf =
    {
        .pin_bit_mask =
            (1ULL << BUZZER_PIN),

        .mode =
            GPIO_MODE_OUTPUT,

        .pull_up_en =
            GPIO_PULLUP_DISABLE,

        .pull_down_en =
            GPIO_PULLDOWN_DISABLE,

        .intr_type =
            GPIO_INTR_DISABLE
    };

    ESP_ERROR_CHECK(
        gpio_config(&io_conf)
    );

    gpio_set_level(
        BUZZER_PIN,
        0
    );

    ESP_LOGI(
        TAG,
        "Buzzer initialized on GPIO %d",
        BUZZER_PIN
    );
}

/* =========================================================
 * APP MAIN
 * ========================================================= */

void app_main(void)
{
    ESP_LOGI(
        TAG,
        "======================================"
    );

    ESP_LOGI(
        TAG,
        " AUTOMATIC SCHOOL BELL"
    );

    ESP_LOGI(
        TAG,
        "======================================"
    );

    /*
     * ------------------------------------------------------
     * 1. Initialize EEPROM / NVS
     * ------------------------------------------------------
     */

    esp_err_t ret =
        eeprom_init();

    if (ret != ESP_OK)
    {
        ESP_LOGE(
            TAG,
            "EEPROM/NVS initialization failed: %s",
            esp_err_to_name(ret)
        );
    }
    else
    {
        ESP_LOGI(
            TAG,
            "EEPROM/NVS initialized"
        );
    }


    /*
     * ------------------------------------------------------
     * 2. Initialize Authentication
     * ------------------------------------------------------
     */

    ret = auth_init();

    if (ret != ESP_OK)
    {
        ESP_LOGE(
            TAG,
            "Authentication initialization failed: %s",
            esp_err_to_name(ret)
        );
    }
    else
    {
        ESP_LOGI(
            TAG,
            "Authentication initialized"
        );
    }
  
 

/*ret = auth_clear_password();

if (ret != ESP_OK)
{
    ESP_LOGE(
        TAG,
        "Failed to clear old password: %s",
        esp_err_to_name(ret)
    );
}
else
{
    ESP_LOGI(
        TAG,
        "Old password cleared successfully"
    );
}*/


    /*
     * ------------------------------------------------------
     * 3. Initialize DS1307 RTC
     * ------------------------------------------------------
     *
     * IMPORTANT:
     * Your rtc.h uses rtc_initialize()
     * NOT rtc_init().
     */

    ret = rtc_initialize();

    if (ret != ESP_OK)
    {
        ESP_LOGE(
            TAG,
            "RTC initialization failed: %s",
            esp_err_to_name(ret)
        );
    }
    else
    {
        ESP_LOGI(
            TAG,
            "RTC initialized successfully"
        );
    }


    /*
     * ------------------------------------------------------
     * 4. Initialize Buzzer
     * ------------------------------------------------------
     */

    buzzer_init();


    /*
     * ------------------------------------------------------
     * 5. Load bell schedule from NVS
     * ------------------------------------------------------
     */

    load_bells_from_eeprom();


    /*
     * ------------------------------------------------------
     * 6. Start Wi-Fi Access Point
     * ------------------------------------------------------
     */

    wifi_init_softap();


    /*
     * ------------------------------------------------------
     * 7. Start Web Server
     * ------------------------------------------------------
     */

    start_webserver();


    /*
     * ------------------------------------------------------
     * 8. Start Automatic Bell Task
     * ------------------------------------------------------
     */

    xTaskCreate(
        bell_task,
        "bell_task",
        4096,
        NULL,
        5,
        NULL
    );


    ESP_LOGI(
        TAG,
        "System initialization complete"
    );

    ESP_LOGI(
        TAG,
        "Connect phone to WiFi: %s",
        WIFI_SSID
    );

    ESP_LOGI(
        TAG,
        "Open: http://192.168.4.1"
    );
}

